CREATE FUNCTION calculate_taggeditems()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN

  IF (TG_OP = 'DELETE') THEN
    UPDATE Tags
    SET Total = (SELECT COUNT(*) FROM TaggedItems WHERE TagId = OLD.TagId)
    WHERE Id = OLD.TagId;
    RETURN OLD;
  ELSE
    UPDATE Tags
    SET Total = (SELECT COUNT(*) FROM TaggedItems WHERE TagId = NEW.TagId)
    WHERE Id = NEW.TagId;
    RETURN NEW;
  END IF;

END;
$$;

