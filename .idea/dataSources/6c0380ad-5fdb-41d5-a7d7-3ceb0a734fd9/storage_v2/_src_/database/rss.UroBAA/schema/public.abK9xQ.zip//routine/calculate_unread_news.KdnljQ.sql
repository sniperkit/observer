CREATE FUNCTION calculate_unread_news()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  UPDATE Feeds
  SET Unread = (SELECT COUNT(*) FROM News WHERE Feed_id = NEW.Feed_id AND READED = 0)
  WHERE Id = NEW.Feed_id;

  RETURN NEW;
END;
$$;

