CREATE FUNCTION calculate_unread_rssitems()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF (TG_OP = 'DELETE') THEN
    UPDATE RssFeed
    SET Unreaded = (SELECT COUNT(*) FROM RssItem WHERE FeedId = OLD.FeedId AND READED = 0),
      Total = (SELECT COUNT(*) FROM RssItem WHERE FeedId = OLD.FeedId)
    WHERE Id = OLD.FeedId;
    RETURN OLD;
  ELSE
    UPDATE RssFeed
    SET Unreaded = (SELECT COUNT(*) FROM RssItem WHERE FeedId = NEW.FeedId AND READED = 0),
      Total = (SELECT COUNT(*) FROM RssItem WHERE FeedId = NEW.FeedId)
    WHERE Id = NEW.FeedId;
    RETURN NEW;
  END IF;

END;
$$;

