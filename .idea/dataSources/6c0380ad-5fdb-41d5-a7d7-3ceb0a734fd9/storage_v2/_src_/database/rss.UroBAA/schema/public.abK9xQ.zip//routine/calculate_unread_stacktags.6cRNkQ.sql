CREATE FUNCTION calculate_unread_stacktags()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  IF (TG_OP = 'DELETE') THEN
    UPDATE StackTags
    SET Unreaded = (SELECT COUNT(*) FROM StackQuestions WHERE Classification = OLD.Classification AND READED = 0)
    WHERE Classification = OLD.Classification;
    RETURN OLD;
  ELSE
    UPDATE StackTags
    SET Unreaded = (SELECT COUNT(*) FROM StackQuestions WHERE Classification = NEW.Classification AND READED = 0)
    WHERE Classification = NEW.Classification;
    RETURN NEW;
  END IF;
END;
$$;

